from openpyxl import load_workbook
import pandas as pd
import matplotlib.pyplot as plt 
  
# x-axis values 
x = [] 
# y-axis values 
y = [] 
  
w=[]
z=[]
sumxy=0
sumx=0
sumy=0
sumx2=0
sumr1=0
sumr2=0
df = pd.read_excel('data.xlsx')
df_rows = df.to_numpy().tolist()
n=len(df_rows)
for j in range(0,9):
    for i in range(0,n):
        x.append(int(df_rows[i][j]))
        y.append(float(df_rows[i][9]))
        tmp_sumxy=int(df_rows[i][j])*float(df_rows[i][9])
        sumxy=sumxy+tmp_sumxy
        sumx=sumx+int(df_rows[i][j])
        sumx2=sumx2+(int(df_rows[i][j])*int(df_rows[i][j]))
        sumy=sumy+float(df_rows[i][9])
    m=round((n*(sumxy)-(sumx*sumy))/(n*(sumx2)-(sumx*sumx)),2)
    b=round((sumy-(m*(sumx)))/n,2)
    for i in range(0,n):
        tmp_r1=(float(df_rows[i][9])-(m*df_rows[i][j]+b))*(float(df_rows[i][9])-(m*df_rows[i][j]+b))
        sumr1=sumr1+tmp_r1
        tmp_r2=(float(df_rows[i][9])-(sumy/n))*(float(df_rows[i][9])-(sumy/n))
        sumr2=sumr2+tmp_r2
        r2=1-(sumr1/sumr2)
    print(r2)
    sumxy=0
    sumx=0
    sumy=0
    sumx2=0
    sumr1=0
    sumr2=0
    for t in range(0,100):
        w.append(t)
        z.append(m*t+b)
    # plotting points as a scatter plot 
    plt.scatter(x, y, color= "green",  
                marker= "*", s=30)
    plt.plot(w, z, color= "black") 
  
    # x-axis label 
    plt.xlabel('attribute') 
    # frequency label 
    plt.ylabel('Grade') 
    # plot title  
    # showing legend 
      
    # function to show the plot 
    plt.show()
    x=[]
    y=[]
    w=[]
    z=[]
